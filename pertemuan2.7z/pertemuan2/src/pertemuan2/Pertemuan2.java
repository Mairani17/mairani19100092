/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan2;

/**
 *
 * @author USER
 */
public class Pertemuan2 {

    /**
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Pertemuan2 per = new Pertemuan2();
        System.out.println("=====Variabel=====");
       per.perVariable();
        System.out.println("=====Percabangan=====");
        per.perPercabanganIf();
        System.out.println("======Hasil=====");
        per.perPercabanganIfElse();
        System.out.println("======Hasil=====");
        per.perPercabanganIfElseIF();
         System.out.println("======Hasil=====");
         per.perPercabanganSWITCHCASE();
          System.out.println("======Hasil=====");
    }
  void perVariable(){
//   deklaasi variable 
    String nama_depan, namaBelakang, alamat; 
    int npm, umur, noHp;
//    mengisi variable(input)
        nama_depan = "mai";
        namaBelakang = "rani";
        alamat = "padang pariaman";
        npm = 19100092;
        umur = 21;
        noHp = 81396386;
//output
      System.out.println("NPM : " + npm);
      System.out.println("NAMA : " + nama_depan + " " + namaBelakang);
      System.out.println("No Hp : " + noHp);
      System.out.println("Alamat : " + alamat);
  }
  void perPercabanganIf(){
       int belanja = 100000;
//      output total belanja 
      System.out.println("Total Belanjaan Rp : " + belanja + "");
      
      if (belanja >= 100000){
          System.out.println("Selamat Anda mendapatkan hadiah");
      }
      System.out.println("terimakasih....");
  }
  void perPercabanganIfElse(){
      int nilai;
      String nama;
      
      nilai = 60;
      nama = "mairani";
//      mengambil input
System.out.println("Nama : " + nilai );
      System.out.println("Nilai : " + nama);
      
//      cek apakah dia lulus atau tidak
if ( nilai >= 70 ) {
    System.out.println("Selamat " + nama + ", anda lulus");
} else {
    System.out.println("Maaf " + nama + ", anda gagal");
}
  }
  void perPercabanganIfElseIF(){
      int nilai;
      String grade;
      System.out.println(" inputkan nilai :");
      nilai = 81;
      
      if (nilai > 90 && nilai <= 100){
          grade = "A";
      } else if (nilai > 80 && nilai <= 90){
          grade = "B+";
      } else if (nilai > 70 && nilai <= 80){
          grade = "B";
      }else if (nilai > 60 && nilai <= 70){
          grade = "C+";
      }else if (nilai > 50 && nilai <= 60){
          grade = "C";
      }else if (nilai > 40 && nilai <= 50){
          grade = "D";
      } else {
          grade = "E";
      }
      System.out.println("Grade : " + grade);
  }
  void perPercabanganSWITCHCASE(){
      String lampu;
      
//     mengambil input
System.out.println("inputkan nama warna : ");
lampu = "merah";

switch (lampu){
    case "merah":
        System.out.println("Lampu merah, berhenti");
        break;
    case "kuning":
        System.out.println("lampu kuning, harap hati - hati");
        break;
    case "hijau":
        System.out.println("lampu hijau, silahkan jalan!");
        break;
    default :
        System.out.println("Warna lampu salah!");
        
}
  }
    
}
